import os  # Import the os module for interacting with the operating system
import sys  # Import the sys module for system-specific parameters and functions
import math  # Import the math module for mathematical functions
import random  # Import the random module for generating random numbers

import pygame  # Import the pygame module for game development and graphics handling

from scripts.utils import load_image, load_images, Animation  # Import utility functions and classes
from scripts.entities import PhysicsEntity, Player, Enemy  # Import game entity classes
from scripts.tilemap import Tilemap  # Import the Tilemap class for managing tiles
from scripts.clouds import Clouds  # Import the Clouds class for cloud management
from scripts.particle import Particle  # Import the Particle class for particle effects
from scripts.spark import Spark  # Import the Spark class for spark effects

class Game:
    def __init__(self):
        pygame.init()  # Initialize all imported pygame modules

        pygame.display.set_caption('ninja game')  # Set the window title
        self.screen = pygame.display.set_mode((1920, 1080))  # Set the screen size to 640x480
        self.display = pygame.Surface((320, 240), pygame.SRCALPHA)  # Create a display surface with alpha channel for effects
        self.display_2 = pygame.Surface((320, 240))  # Create a secondary display surface for rendering

        self.clock = pygame.time.Clock()  # Create a clock object to manage the frame rate
        
        self.movement = [False, False]  # Initialize movement state: [left, right]
        
        self.assets = {  # Load and store game assets
            'decor': load_images('tiles/decor'),  # Load decorative tile images
            'grass': load_images('tiles/grass'),  # Load grass tile images
            'large_decor': load_images('tiles/large_decor'),  # Load large decorative tile images
            'stone': load_images('tiles/stone'),  # Load stone tile images
            'player': load_image('entities/player.png'),  # Load player sprite
            'background': load_image('background.png'),  # Load background image
            'clouds': load_images('clouds'),  # Load cloud images
            'enemy/idle': Animation(load_images('entities/enemy/idle'), img_dur=6),  # Load enemy idle animation
            'enemy/run': Animation(load_images('entities/enemy/run'), img_dur=4),  # Load enemy run animation
            'player/idle': Animation(load_images('entities/player/idle'), img_dur=6),  # Load player idle animation
            'player/run': Animation(load_images('entities/player/run'), img_dur=4),  # Load player run animation
            'player/jump': Animation(load_images('entities/player/jump')),  # Load player jump animation
            'player/slide': Animation(load_images('entities/player/slide')),  # Load player slide animation
            'player/wall_slide': Animation(load_images('entities/player/wall_slide')),  # Load player wall slide animation
            'particle/leaf': Animation(load_images('particles/leaf'), img_dur=20, loop=False),  # Load leaf particle animation
            'particle/particle': Animation(load_images('particles/particle'), img_dur=6, loop=False),  # Load generic particle animation
            'gun': load_image('gun.png'),  # Load gun image
            'projectile': load_image('projectile.png'),  # Load projectile image
        }
        
        self.sfx = {  # Load and store sound effects
            'jump': pygame.mixer.Sound('data/sfx/jump.wav'),  # Load jump sound effect
            'dash': pygame.mixer.Sound('data/sfx/dash.wav'),  # Load dash sound effect
            'hit': pygame.mixer.Sound('data/sfx/hit.wav'),  # Load hit sound effect
            'shoot': pygame.mixer.Sound('data/sfx/shoot.wav'),  # Load shoot sound effect
            'ambience': pygame.mixer.Sound('data/sfx/ambience.wav'),  # Load ambience sound effect
        }

        # Set volumes for each sound effect
        self.sfx['ambience'].set_volume(0.2)  # Set volume for ambience sound effect
        self.sfx['shoot'].set_volume(0.4)  # Set volume for shoot sound effect
        self.sfx['hit'].set_volume(0.8)  # Set volume for hit sound effect
        self.sfx['dash'].set_volume(0.3)  # Set volume for dash sound effect
        self.sfx['jump'].set_volume(0.7)  # Set volume for jump sound effect

        self.clouds = Clouds(self.assets['clouds'], count=16)  # Create Clouds object with 16 clouds
        
        self.player = Player(self, (50, 50), (8, 15))  # Initialize player at position (50, 50) with size (8, 15)
        
        self.tilemap = Tilemap(self, tile_size=16)  # Initialize tilemap with tile size of 16
        
        self.level = 0  # Set initial level to 0
        self.load_level(self.level)  # Load the level data
        
        self.screenshake = 0  # Initialize screenshake effect to 0
        
    def load_level(self, map_id):
        self.tilemap.load('data/maps/' + str(map_id) + '.json')  # Load level data from JSON file
        
        self.leaf_spawners = []  # Initialize leaf spawners list
        for tree in self.tilemap.extract([('large_decor', 2)], keep=True):  # Extract large decor tiles for leaf spawners
            self.leaf_spawners.append(pygame.Rect(4 + tree['pos'][0], 4 + tree['pos'][1], 23, 13))  # Create rects for leaf spawners
            
        self.enemies = []  # Initialize enemies list
        for spawner in self.tilemap.extract([('spawners', 0), ('spawners', 1)]):  # Extract spawner tiles
            if spawner['variant'] == 0:
                self.player.pos = spawner['pos']  # Set player position to spawner position
                self.player.air_time = 0  # Reset player air time
            else:
                self.enemies.append(Enemy(self, spawner['pos'], (8, 15)))  # Create enemies at spawner positions
            
        self.projectiles = []  # Initialize projectiles list
        self.particles = []  # Initialize particles list
        self.sparks = []  # Initialize sparks list
        
        self.scroll = [0, 0]  # Initialize scroll position
        self.dead = 0  # Initialize dead state
        self.transition = -30  # Initialize transition state
        
    def run(self):
        pygame.mixer.music.load('data/music.wav')  # Load background music
        pygame.mixer.music.set_volume(0.5)  # Set volume for background music
        pygame.mixer.music.play(-1)  # Play background music in loop

        self.sfx['ambience'].play(-1)  # Play ambience sound effect in loop

        while True:  # Main game loop
            self.display.fill((0, 0, 0, 0))  # Clear the display surface with transparent color
            self.display_2.blit(self.assets['background'], (0, 0))  # Draw background image on secondary display
            
            self.screenshake = max(0, self.screenshake - 1)  # Reduce screenshake effect over time
            
            if not len(self.enemies):  # Check if there are no enemies left
                self.transition += 1  # Increment transition state
                if self.transition > 30:  # Check if transition state exceeds 30
                    self.level = min(self.level + 1, len(os.listdir('data/maps')) - 1)  # Move to the next level
                    self.load_level(self.level)  # Load the new level
            if self.transition < 0:  # Check if transition state is less than 0
                self.transition += 1  # Increment transition state
            
            if self.dead:  # Check if player is dead
                self.dead += 1  # Increment dead state
                if self.dead >= 10:  # Check if dead state exceeds 10
                    self.transition = min(30, self.transition + 1)  # Increment transition state
                if self.dead > 40:  # Check if dead state exceeds 40
                    self.load_level(self.level)  # Reload the current level
            
            # Update scroll position to follow the player
            self.scroll[0] += (self.player.rect().centerx - self.display.get_width() / 2 - self.scroll[0]) / 30
            self.scroll[1] += (self.player.rect().centery - self.display.get_height() / 2 - self.scroll[1]) / 30
            render_scroll = (int(self.scroll[0]), int(self.scroll[1]))  # Convert scroll to integer
            
            # Create particles at leaf spawners
            for rect in self.leaf_spawners:
                if random.random() * 49999 < rect.width * rect.height:  # Randomly decide if particles should spawn
                    pos = (rect.x + random.random() * rect.width, rect.y + random.random() * rect.height)  # Random position within the rect
                    self.particles.append(Particle(self, 'leaf', pos, velocity=[-0.1, 0.3], frame=random.randint(0, 20)))  # Create leaf particle
            
            self.clouds.update()  # Update cloud animations
            self.clouds.render(self.display_2, offset=render_scroll)  # Render clouds on secondary display
            
            self.tilemap.render(self.display, offset=render_scroll)  # Render the tilemap
            
            # Update and render enemies
            for enemy in self.enemies.copy():
                kill = enemy.update(self.tilemap, (0, 0))  # Update enemy state
                enemy.render(self.display, offset=render_scroll)  # Render enemy
                if kill:  # Check if the enemy should be killed
                    self.enemies.remove(enemy)  # Remove enemy from the list
            
            if not self.dead:  # Update and render player only if not dead
                self.player.update(self.tilemap, (self.movement[1] - self.movement[0], 0))  # Update player state
                self.player.render(self.display, offset=render_scroll)  # Render player
            
            # Update and render projectiles
            for projectile in self.projectiles.copy():
                projectile[0][0] += projectile[1]  # Move projectile
                projectile[2] += 1  # Increment projectile timer
                img = self.assets['projectile']  # Get projectile image
                self.display.blit(img, (projectile[0][0] - img.get_width() / 2 - render_scroll[0], projectile[0][1] - img.get_height() / 2 - render_scroll[1]))  # Draw projectile
                if self.tilemap.solid_check(projectile[0]):  # Check if projectile collides with a solid tile
                    self.projectiles.remove(projectile)  # Remove projectile
                    for i in range(4):  # Create sparks on collision
                        self.sparks.append(Spark(projectile[0], random.random() - 0.5 + (math.pi if projectile[1] > 0 else 0), 2 + random.random()))
                elif projectile[2] > 360:  # Check if projectile has existed for too long
                    self.projectiles.remove(projectile)  # Remove projectile
                elif abs(self.player.dashing) < 50:  # Check if player is close to projectile
                    if self.player.rect().collidepoint(projectile[0]):  # Check if projectile collides with player
                        self.projectiles.remove(projectile)  # Remove projectile
                        self.dead += 1  # Increment dead state
                        self.sfx['hit'].play()  # Play hit sound effect
                        self.screenshake = max(16, self.screenshake)  # Increase screenshake effect
                        for i in range(30):  # Create sparks and particles on hit
                            angle = random.random() * math.pi * 2
                            speed = random.random() * 5
                            self.sparks.append(Spark(self.player.rect().center, angle, 2 + random.random()))
                            self.particles.append(Particle(self, 'particle', self.player.rect().center, velocity=[math.cos(angle + math.pi) * speed * 0.5, math.sin(angle + math.pi) * speed * 0.5], frame=random.randint(0, 7)))
                        
            # Update and render sparks
            for spark in self.sparks.copy():
                kill = spark.update()  # Update spark state
                spark.render(self.display, offset=render_scroll)  # Render spark
                if kill:  # Check if the spark should be killed
                    self.sparks.remove(spark)  # Remove spark from the list
            
            # Create and apply silhouette effect for smooth transitions
            display_mask = pygame.mask.from_surface(self.display)  # Create mask from display surface
            display_sillhouette = display_mask.to_surface(setcolor=(0, 0, 0, 180), unsetcolor=(0, 0, 0, 0))  # Create silhouette surface
            for offset in [(-1, 0), (1, 0), (0, -1), (0, 1)]:  # Apply silhouette effect in four directions
                self.display_2.blit(display_sillhouette, offset)

            # Update and render particles
            for particle in self.particles.copy():
                kill = particle.update()  # Update particle state
                particle.render(self.display, offset=render_scroll)  # Render particle
                if particle.type == 'leaf':  # Check if particle is a leaf
                    particle.pos[0] += math.sin(particle.animation.frame * 0.035) * 0.3  # Add movement effect to leaf particle
                if kill:  # Check if the particle should be killed
                    self.particles.remove(particle)  # Remove particle from the list
            
            # Handle user input events
            for event in pygame.event.get():  # Get all events
                if event.type == pygame.QUIT:  # Check if quit event
                    pygame.quit()  # Quit pygame
                    sys.exit()  # Exit the program
                if event.type == pygame.KEYDOWN:  # Check if a key was pressed down
                    if event.key == pygame.K_LEFT:  # Check if the left arrow key was pressed
                        self.movement[0] = True  # Set left movement to true
                    if event.key == pygame.K_RIGHT:  # Check if the right arrow key was pressed
                        self.movement[1] = True  # Set right movement to true
                    if event.key == pygame.K_UP:  # Check if the up arrow key was pressed
                        if self.player.jump():  # Check if the player can jump
                            self.sfx['jump'].play()  # Play jump sound effect
                    if event.key == pygame.K_x:  # Check if the x key was pressed
                        self.player.dash()  # Execute player dash action
                if event.type == pygame.KEYUP:  # Check if a key was released
                    if event.key == pygame.K_LEFT:  # Check if the left arrow key was released
                        self.movement[0] = False  # Set left movement to false
                    if event.key == pygame.K_RIGHT:  # Check if the right arrow key was released
                        self.movement[1] = False  # Set right movement to false
                        
            if self.transition:  # Check if there is a transition effect
                transition_surf = pygame.Surface(self.display.get_size())  # Create a surface for the transition effect
                pygame.draw.circle(transition_surf, (255, 255, 255), (self.display.get_width() // 2, self.display.get_height() // 2), (30 - abs(self.transition)) * 8)  # Draw a circle for the transition effect
                transition_surf.set_colorkey((255, 255, 255))  # Set white color as transparent
                self.display.blit(transition_surf, (0, 0))  # Apply the transition effect to the display
            
            self.display_2.blit(self.display, (0, 0))  # Blit the display surface onto the secondary display

            screenshake_offset = (random.random() * self.screenshake - self.screenshake / 2, random.random() * self.screenshake - self.screenshake / 2)  # Calculate screenshake offset
            self.screen.blit(pygame.transform.scale(self.display_2, self.screen.get_size()), screenshake_offset)  # Scale and blit the secondary display to the main screen with screenshake effect
            pygame.display.update()  # Update the display
            self.clock.tick(60)  # Cap the frame rate to 60 FPS

Game().run()  # Create a Game object and run the game
