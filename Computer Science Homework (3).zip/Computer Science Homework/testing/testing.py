
        #self.img = pygame.image.load('data/images/clouds/cloud_1.png')#loads an image
        #self.img.set_colorkey ((0,0,0)) #sets a color key so image is transparent. 

        #self.img_pos = [160,200] #defines where the image is supposed to be
        #self.movement = [False, False]

        #self.collision_area = pygame.Rect(50,50,300,50)  # Creates a rectangle area to check for collisions

#self.img_pos[1] += (self.movement[1] - self.movement[0]) * 5 #if up key is pressed self movement[0] will be true and down key is not pressed self.movement[1] is false which then evaluates to -1, but then multiplied by 5 meaning it moves by -5 pixels, so 5 pixels up. 
            #self.screen.blit(self.img, self.img_pos)#draws the image at specified coordinates. blit stands for block transfer, moves one pixel of data from one surface to another.    

            #img_r = pygame.Rect(self.img_pos[0],self.img_pos[1], self.img.get_width(), self.img.get_height()) #pygame.Rect just creates a rectangle. get_width and get_height is just recording the l and w of an image.
            #if img_r.colliderect(self.collision_area): # Checks if the image rectangle collides with the collision area
                #pygame.draw.rect(self.screen ,(0,100,255), self.collision_area)   # If there is a collision, draw the collision area in a different color
            #else: 
                #pygame.draw.rect(self.screen ,(0,50,155), self.collision_area) # If there is no collision, draw the collision area in another color