import math  # Import math module for mathematical operations
import random  # Import random module for generating random numbers
import pygame  # Import pygame module for game development

from scripts.particle import Particle  # Import Particle class from scripts.particle module
from scripts.spark import Spark  # Import Spark class from scripts.spark module

# Define a base class for entities with physics
class PhysicsEntity:
    def __init__(self, game, e_type, pos, size):
        self.game = game  # Reference to the game instance
        self.type = e_type  # Entity type (e.g., 'player', 'enemy')
        self.pos = list(pos)  # Position of the entity as a mutable list
        self.size = size  # Size of the entity
        self.velocity = [0, 0]  # Velocity of the entity in both x and y directions
        self.collisions = {'up': False, 'down': False, 'right': False, 'left': False}  # Collision states
        
        self.action = ''  # Current action/animation state
        self.anim_offset = (-3, -3)  # Offset for rendering animation
        self.flip = False  # Flip flag for horizontal flipping of the sprite
        self.set_action('idle')  # Set initial action to 'idle'
        
        self.last_movement = [0, 0]  # Store the las    t movement vector
    
    # Create a rectangle representing the entity's position and size
    def rect(self):
        return pygame.Rect(self.pos[0], self.pos[1], self.size[0], self.size[1])
    
    # Change the entity's action/animation state
    def set_action(self, action):
        if action != self.action:  # Only update if the action is different from the current one
            self.action = action  # Set the new action
            # Load the corresponding animation for the action
            self.animation = self.game.assets[self.type + '/' + self.action].copy()
        
    # Update the entity's position and handle collisions
    def update(self, tilemap, movement=(0, 0)):
        self.collisions = {'up': False, 'down': False, 'right': False, 'left': False}  # Reset collision states
        
        # Calculate movement for the current frame
        frame_movement = (movement[0] + self.velocity[0], movement[1] + self.velocity[1])
        
        # Update horizontal position and check for collisions
        self.pos[0] += frame_movement[0]
        entity_rect = self.rect()
        for rect in tilemap.physics_rects_around(self.pos):  # Check collisions with nearby tiles
            if entity_rect.colliderect(rect):  # If collision detected
                if frame_movement[0] > 0:  # Moving right
                    entity_rect.right = rect.left
                    self.collisions['right'] = True
                if frame_movement[0] < 0:  # Moving left
                    entity_rect.left = rect.right
                    self.collisions['left'] = True
                self.pos[0] = entity_rect.x  # Adjust position based on collision
        
        # Update vertical position and check for collisions
        self.pos[1] += frame_movement[1]
        entity_rect = self.rect()
        for rect in tilemap.physics_rects_around(self.pos):  # Check collisions with nearby tiles
            if entity_rect.colliderect(rect):  # If collision detected
                if frame_movement[1] > 0:  # Moving down
                    entity_rect.bottom = rect.top
                    self.collisions['down'] = True
                if frame_movement[1] < 0:  # Moving up
                    entity_rect.top = rect.bottom
                    self.collisions['up'] = True
                self.pos[1] = entity_rect.y  # Adjust position based on collision
                
        # Update sprite flipping based on horizontal movement
        if movement[0] > 0:
            self.flip = False  # Facing right
        if movement[0] < 0:
            self.flip = True  # Facing left
            
        self.last_movement = movement  # Store the last movement
        
        self.velocity[1] = min(5, self.velocity[1] + 0.1)  # Apply gravity
        
        if self.collisions['down'] or self.collisions['up']:
            self.velocity[1] = 0  # Stop vertical velocity on collision
            
        self.animation.update()  # Update the animation frame
        
    # Render the entity on the screen
    def render(self, surf, offset=(0, 0)):
        # Draw the entity's sprite, applying flipping and offset
        surf.blit(
            pygame.transform.flip(self.animation.img(), self.flip, False),
            (self.pos[0] - offset[0] + self.anim_offset[0], self.pos[1] - offset[1] + self.anim_offset[1])
        )

# Define an Enemy class that inherits from PhysicsEntity
class Enemy(PhysicsEntity):
    def __init__(self, game, pos, size):
        super().__init__(game, 'enemy', pos, size)  # Initialize the base class
        
        self.walking = 0  # Timer for walking state
        
    def update(self, tilemap, movement=(0, 0)):
        if self.walking:  # If the enemy is in a walking state
            # Check if there is a solid tile in front of the enemy
            if tilemap.solid_check((self.rect().centerx + (-7 if self.flip else 7), self.pos[1] + 23)):
                if (self.collisions['right'] or self.collisions['left']):  # Check for collisions on sides
                    self.flip = not self.flip  # Change direction
                else:
                    movement = (movement[0] - 0.5 if self.flip else 0.5, movement[1])  # Move in the walking direction
            else:
                self.flip = not self.flip  # Change direction if no solid ground ahead
            self.walking = max(0, self.walking - 1)  # Decrease walking timer
            if not self.walking:  # If walking timer ends
                dis = (self.game.player.pos[0] - self.pos[0], self.game.player.pos[1] - self.pos[1])
                if (abs(dis[1]) < 16):  # Check if the player is within a certain vertical range
                    if (self.flip and dis[0] < 0):  # If facing the player and player is to the left
                        self.game.sfx['shoot'].play()  # Play shooting sound effect
                        # Shoot a projectile towards the player
                        self.game.projectiles.append([[self.rect().centerx - 7, self.rect().centery], -1.5, 0])
                        # Generate sparks effect
                        for i in range(4):
                            self.game.sparks.append(Spark(self.game.projectiles[-1][0], random.random() - 0.5 + math.pi, 2 + random.random()))
                    if (not self.flip and dis[0] > 0):  # If facing the player and player is to the right
                        self.game.projectiles.append([[self.rect().centerx + 7, self.rect().centery], 1.5, 0])
                        for i in range(4):
                            self.game.sparks.append(Spark(self.game.projectiles[-1][0], random.random() - 0.5, 2 + random.random()))
        elif random.random() < 0.01:  # Randomly initiate walking state
            self.walking = random.randint(30, 120)  # Set walking timer to a random duration
        
        super().update(tilemap, movement=movement)  # Call the base class update
        
        # Update action based on movement
        if movement[0] != 0:
            self.set_action('run')  # Set running animation if moving
        else:
            self.set_action('idle')  # Set idle animation if stationary
            
        # Check if the player is dashing with high speed
        if abs(self.game.player.dashing) >= 50:
            if self.rect().colliderect(self.game.player.rect()):  # If the enemy collides with the player
                self.game.screenshake = max(16, self.game.screenshake)  # Trigger a screen shake effect
                self.game.sfx['hit'].play()  # Play hit sound effect
                # Generate spark and particle effects on hit
                for i in range(30):
                    angle = random.random() * math.pi * 2
                    speed = random.random() * 5
                    self.game.sparks.append(Spark(self.rect().center, angle, 2 + random.random()))
                    self.game.particles.append(Particle(self.game, 'particle', self.rect().center, velocity=[math.cos(angle + math.pi) * speed * 0.5, math.sin(angle + math.pi) * speed * 0.5], frame=random.randint(0, 7)))
                self.game.sparks.append(Spark(self.rect().center, 0, 5 + random.random()))
                self.game.sparks.append(Spark(self.rect().center, math.pi, 5 + random.random()))
                return True  # Return True to indicate the enemy was hit
            
    # Render the enemy on the screen
    def render(self, surf, offset=(0, 0)):
        super().render(surf, offset=offset)  # Call the base class render
        
        # Draw the gun sprite depending on the direction the enemy is facing
        if self.flip:
            surf.blit(pygame.transform.flip(self.game.assets['gun'], True, False), (self.rect().centerx - 4 - self.game.assets['gun'].get_width() - offset[0], self.rect().centery - offset[1]))
        else:
            surf.blit(self.game.assets['gun'], (self.rect().centerx + 4 - offset[0], self.rect().centery - offset[1]))

# Define a Player class that inherits from PhysicsEntity
class Player(PhysicsEntity):
    def __init__(self, game, pos, size):
        super().__init__(game, 'player', pos, size)  # Initialize the base class
        self.air_time = 0  # Time spent in the air
        self.jumps = 1  # Number of available jumps
        self.wall_slide = False  # Flag for wall slide state
        self.dashing = 0  # Dashing state
    
    def update(self, tilemap, movement=(0, 0)):
        super().update(tilemap, movement=movement)  # Call the base class update
        
        self.air_time += 1  # Increase air time
        
        if self.air_time > 120:  # If air time exceeds a limit
            if not self.game.dead:  # If player is not dead
                self.game.screenshake = max(16, self.game.screenshake)  # Trigger a screen shake effect
            self.game.dead += 1  # Increase death timer
        
        if self.collisions['down']:  # If player is on the ground
            self.air_time = 0  # Reset air time
            self.jumps = 1  # Reset jumps
            
        self.wall_slide = False  # Reset wall slide state
        if (self.collisions['right'] or self.collisions['left']) and self.air_time > 4:  # Check for wall slide conditions
            self.wall_slide = True  # Enable wall slide
            self.velocity[1] = min(self.velocity[1], 0.5)  # Slow down vertical movement
            if self.collisions['right']:
                self.flip = False  # Face right
            else:
                self.flip = True  # Face left
            self.set_action('wall_slide')  # Set wall slide animation
        
        # Update action based on state and movement
        if not self.wall_slide:
            if self.air_time > 4:
                self.set_action('jump')  # Set jump animation if in the air
            elif movement[0] != 0:
                self.set_action('run')  # Set running animation if moving
            else:
                self.set_action('idle')  # Set idle animation if stationary
        
        # Handle dash effects
        if abs(self.dashing) in {60, 50}:  # If dashing with specific speeds
            for i in range(20):
                angle = random.random() * math.pi * 2
                speed = random.random() * 0.5 + 0.5
                pvelocity = [math.cos(angle) * speed, math.sin(angle) * speed]
                self.game.particles.append(Particle(self.game, 'particle', self.rect().center, velocity=pvelocity, frame=random.randint(0, 7)))
        if self.dashing > 0:  # Decrease dash timer if dashing to the right
            self.dashing = max(0, self.dashing - 1)
        if self.dashing < 0:  # Increase dash timer if dashing to the left
            self.dashing = min(0, self.dashing + 1)
        if abs(self.dashing) > 50:  # Apply high-speed dash movement
            self.velocity[0] = abs(self.dashing) / self.dashing * 8
            if abs(self.dashing) == 51:
                self.velocity[0] *= 0.1
            pvelocity = [abs(self.dashing) / self.dashing * random.random() * 3, 0]
            self.game.particles.append(Particle(self.game, 'particle', self.rect().center, velocity=pvelocity, frame=random.randint(0, 7)))
                
        # Apply friction to horizontal movement
        if self.velocity[0] > 0:
            self.velocity[0] = max(self.velocity[0] - 0.1, 0)
        else:
            self.velocity[0] = min(self.velocity[0] + 0.1, 0)
    
    # Render the player on the screen
    def render(self, surf, offset=(0, 0)):
        if abs(self.dashing) <= 50:  # Only render if not in high-speed dash
            super().render(surf, offset=offset)
            
    # Handle jump input
    def jump(self):
        if self.wall_slide:  # If wall sliding
            if self.flip and self.last_movement[0] < 0:
                self.velocity[0] = 3.5  # Apply wall jump to the right
                self.velocity[1] = -2.5  # Apply upward velocity
                self.air_time = 5
                self.jumps = max(0, self.jumps - 1)  # Decrease available jumps
                return True
            elif not self.flip and self.last_movement[0] > 0:
                self.velocity[0] = -3.5  # Apply wall jump to the left
                self.velocity[1] = -2.5  # Apply upward velocity
                self.air_time = 5
                self.jumps = max(0, self.jumps - 1)  # Decrease available jumps
                return True
                
        elif self.jumps:  # If jumps are available
            self.velocity[1] = -3  # Apply upward velocity
            self.jumps -= 1  # Decrease available jumps
            self.air_time = 5
            return True
    
    # Handle dash input
    def dash(self):
        if not self.dashing:  # If not already dashing
            self.game.sfx['shoot'].play()  # Play dash sound effect
            if self.flip:
                self.dashing = -60  # Start dash to the left
            else:
                self.dashing = 60  # Start dash to the right
