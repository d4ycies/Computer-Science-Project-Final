import math
import pygame

class Spark:
    def __init__(self, pos, angle, speed):
        # Initialize the spark with its position, angle of movement, and speed.
        self.pos = list(pos)  # Convert position to a list [x, y] to easily manipulate coordinates.
        self.angle = angle  # Store the angle in radians to determine the direction of movement.
        self.speed = speed  # Set the initial speed of the spark, which will decrease over time.
        
    def update(self):
        # Update the position of the spark based on its angle and speed.
        self.pos[0] += math.cos(self.angle) * self.speed  # Move the spark horizontally based on the angle and speed.
        self.pos[1] += math.sin(self.angle) * self.speed  # Move the spark vertically based on the angle and speed.
        
        # Gradually reduce the speed of the spark to simulate friction or resistance.
        self.speed = max(0, self.speed - 0.1)  # Ensure the speed never goes below 0.
        return not self.speed  # Return True if the spark has stopped moving (speed is 0).
    
    def render(self, surf, offset=(0, 0)):
        # Calculate the points for rendering the spark as a small polygon.
        render_points = [
            # Point in the direction of movement, extended by 3 times the current speed.
            (self.pos[0] + math.cos(self.angle) * self.speed * 3 - offset[0], 
             self.pos[1] + math.sin(self.angle) * self.speed * 3 - offset[1]),
             
            # Point 90 degrees clockwise from the direction of movement, slightly offset.
            (self.pos[0] + math.cos(self.angle + math.pi * 0.5) * self.speed * 0.5 - offset[0], 
             self.pos[1] + math.sin(self.angle + math.pi * 0.5) * self.speed * 0.5 - offset[1]),
             
            # Point opposite to the direction of movement, extended by 3 times the current speed.
            (self.pos[0] + math.cos(self.angle + math.pi) * self.speed * 3 - offset[0], 
             self.pos[1] + math.sin(self.angle + math.pi) * self.speed * 3 - offset[1]),
             
            # Point 90 degrees counterclockwise from the direction of movement, slightly offset.
            (self.pos[0] + math.cos(self.angle - math.pi * 0.5) * self.speed * 0.5 - offset[0], 
             self.pos[1] + math.sin(self.angle - math.pi * 0.5) * self.speed * 0.5 - offset[1]),
        ]
        
        # Render the spark as a white polygon on the surface.
        pygame.draw.polygon(surf, (255, 255, 255), render_points)  # Draw the polygon with the calculated points.


#Initialization (__init__):

#The spark is initialized with its starting position (pos), the direction it will travel (angle), and its speed.
#Position is stored as a mutable list to facilitate easy updates during the spark's movement.

#Update (update):

#The spark's position is updated based on its current speed and direction (angle).
#The speed is gradually reduced to simulate a slowing effect, eventually stopping the spark.
#The method returns True if the spark has come to a complete stop, allowing the game to remove it if needed.

#Render (render):

#The render method calculates the vertices of a polygon representing the spark, based on its position, angle, and speed.
#The polygon is drawn onto the provided surface (surf) as a small white shape, representing the spark's current state.
#The offset parameter allows the rendering to account for camera movement or other positional adjustments.