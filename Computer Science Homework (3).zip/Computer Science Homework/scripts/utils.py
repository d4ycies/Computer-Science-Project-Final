import os  # Import the os module for interacting with the operating system
import pygame  # Import the pygame module for game development and graphics handling

BASE_IMG_PATH = 'data/images/'  # Define the base path where images are stored

def load_image(path):
    # Load an image from the given path, convert it to a format suitable for faster blitting, and set its transparency color to black
    img = pygame.image.load(BASE_IMG_PATH + path).convert()  # Load and convert the image
    img.set_colorkey((0, 0, 0))  # Set black as the transparent color
    return img  # Return the processed image

def load_images(path):
    # Load all images from the given directory path
    images = []  # Initialize an empty list to store the images
    for img_name in sorted(os.listdir(BASE_IMG_PATH + path)):  # Iterate over all files in the directory, sorted by name
        images.append(load_image(path + '/' + img_name))  # Load each image and append it to the list
    return images  # Return the list of loaded images

class Animation:
    def __init__(self, images, img_dur=5, loop=True):
        # Initialize the animation with a list of images, duration per image, and a loop flag
        self.images = images  # Store the list of images
        self.loop = loop  # Store the loop flag
        self.img_duration = img_dur  # Store the duration each image should be displayed
        self.done = False  # Flag to indicate if the animation has completed
        self.frame = 0  # Initialize the current frame to 0
    
    def copy(self):
        # Return a new Animation object with the same properties
        return Animation(self.images, self.img_duration, self.loop)
    
    def update(self):
        # Update the current frame of the animation
        if self.loop:
            # If the animation should loop, cycle through frames continuously
            self.frame = (self.frame + 1) % (self.img_duration * len(self.images))
        else:
            # If the animation should not loop, increment the frame until it reaches the end
            self.frame = min(self.frame + 1, self.img_duration * len(self.images) - 1)
            if self.frame >= self.img_duration * len(self.images) - 1:
                self.done = True  # Set the done flag when the animation reaches the end
    
    def img(self):
        # Return the current image based on the frame
        return self.images[int(self.frame / self.img_duration)]  # Calculate the index of the current image and return it

#import os: Imports the os module, which provides functions for interacting with the file system.
#import pygame: Imports the pygame module, which is used for creating games and handling graphics.
#BASE_IMG_PATH: Specifies the base directory where images are stored.
#load_image(path): Function to load a single image, convert it to a format suitable for Pygame, and set black as transparent.
#load_images(path): Function to load multiple images from a specified directory, sorting them by filename.
#class Animation: Defines an Animation class to handle a sequence of images that play in a loop or once.
    #__init__: Initializes the animation with images, duration, and looping behavior.
    #copy(): Creates a copy of the animation object.
    #update(): Updates the animation frame, handling looping and non-looping cases.
    #img(): Returns the current image based on the current frame.