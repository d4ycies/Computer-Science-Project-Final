class Particle:
    def __init__(self, game, p_type, pos, velocity=[0, 0], frame=0):
        # Initialize the particle with references to the game, particle type, position, velocity, and starting animation frame.
        self.game = game  # Store reference to the game instance, allowing access to game-wide assets and properties.
        self.type = p_type  # Define the type of particle (e.g., 'explosion', 'smoke') to determine the animation.
        self.pos = list(pos)  # Convert the position to a mutable list [x, y] for easier manipulation.
        self.velocity = list(velocity)  # Convert the velocity to a list to allow for movement updates in both x and y directions.
        self.animation = self.game.assets['particle/' + p_type].copy()  # Load the particle's animation based on its type.
        self.animation.frame = frame  # Set the starting frame of the animation, useful for timing or reusing particles.
    
    def update(self):
        # Update the particle's state, including its position and animation frame.
        kill = False  # Initialize a flag to determine if the particle should be removed.
        if self.animation.done:  # Check if the animation has finished playing all its frames.
            kill = True  # Mark the particle for removal if the animation is complete.
        
        # Update the particle's position based on its current velocity.
        self.pos[0] += self.velocity[0]  # Increment the x-position by the x-component of the velocity.
        self.pos[1] += self.velocity[1]  # Increment the y-position by the y-component of the velocity.
        
        self.animation.update()  # Progress the animation to the next frame.
        
        return kill  # Return the 'kill' flag indicating whether the particle should be removed.
    
    def render(self, surf, offset=(0, 0)):
        # Render the particle's current frame onto the given surface, adjusted by an offset.
        img = self.animation.img()  # Get the current image/frame of the animation.
        # Blit (draw) the image onto the surface at the calculated position, centered on the particle's position.
        surf.blit(img, (self.pos[0] - offset[0] - img.get_width() // 2, 
                        self.pos[1] - offset[1] - img.get_height() // 2))
