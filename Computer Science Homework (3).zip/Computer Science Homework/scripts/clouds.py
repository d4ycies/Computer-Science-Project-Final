import random  # Import the random module for generating random numbers

# Define the Cloud class
class Cloud:
    def __init__(self, pos, img, speed, depth):
        self.pos = list(pos)  # Initialize the position of the cloud as a list for mutable coordinates
        self.img = img  # Store the image of the cloud
        self.speed = speed  # Set the horizontal movement speed of the cloud
        self.depth = depth  # Set the depth of the cloud, which affects parallax scrolling
    
    # Update the position of the cloud
    def update(self):
        self.pos[0] += self.speed  # Move the cloud horizontally based on its speed
        
    # Render the cloud on the given surface
    def render(self, surf, offset=(0, 0)):
        # Calculate the render position of the cloud, applying the offset and depth for parallax effect
        render_pos = (self.pos[0] - offset[0] * self.depth, self.pos[1] - offset[1] * self.depth)
        
        # Draw the cloud on the surface, wrapping it around the screen if it goes off the edge
        surf.blit(self.img, (
            render_pos[0] % (surf.get_width() + self.img.get_width()) - self.img.get_width(),  # Horizontal wrapping
            render_pos[1] % (surf.get_height() + self.img.get_height()) - self.img.get_height()  # Vertical wrapping
        ))

# Define the Clouds class, which manages multiple cloud instances
class Clouds:
    def __init__(self, cloud_images, count=16):
        self.clouds = []  # Initialize an empty list to store cloud instances
        
        # Create the specified number of cloud instances
        for i in range(count):
            # Append a new Cloud object with random position, image, speed, and depth
            self.clouds.append(Cloud(
                (random.random() * 99999, random.random() * 99999),  # Random starting position far off-screen
                random.choice(cloud_images),  # Randomly select a cloud image
                random.random() * 0.05 + 0.05,  # Random horizontal speed between 0.05 and 0.1
                random.random() * 0.6 + 0.2  # Random depth between 0.2 and 0.8, affecting parallax
            ))
        
        self.clouds.sort(key=lambda x: x.depth)  # Sort clouds by depth to render them in the correct order
    
    # Update the position of all clouds
    def update(self):
        for cloud in self.clouds:  # Iterate through each cloud
            cloud.update()  # Update the cloud's position
    
    # Render all clouds on the given surface
    def render(self, surf, offset=(0, 0)):
        for cloud in self.clouds:  # Iterate through each cloud
            cloud.render(surf, offset=offset)  # Render the cloud on the surface with the given offset
