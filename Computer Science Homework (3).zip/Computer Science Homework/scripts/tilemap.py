import json  # Import the JSON module for saving and loading tilemap data
import pygame  # Import pygame for rendering and graphical operations

# Dictionary mapping specific neighbor patterns to autotile variants
AUTOTILE_MAP = {
    tuple(sorted([(1, 0), (0, 1)])): 0,  # Right and Down
    tuple(sorted([(1, 0), (0, 1), (-1, 0)])): 1,  # Right, Down, and Left
    tuple(sorted([(-1, 0), (0, 1)])): 2,  # Left and Down
    tuple(sorted([(-1, 0), (0, -1), (0, 1)])): 3,  # Left, Up, and Down
    tuple(sorted([(-1, 0), (0, -1)])): 4,  # Left and Up
    tuple(sorted([(-1, 0), (0, -1), (1, 0)])): 5,  # Left, Up, and Right
    tuple(sorted([(1, 0), (0, -1)])): 6,  # Right and Up
    tuple(sorted([(1, 0), (0, -1), (0, 1)])): 7,  # Right, Up, and Down
    tuple(sorted([(1, 0), (-1, 0), (0, 1), (0, -1)])): 8,  # All sides
}

# Offsets to check the 8 neighboring positions around a tile
NEIGHBOR_OFFSETS = [(-1, 0), (-1, -1), (0, -1), (1, -1), (1, 0), (0, 0), (-1, 1), (0, 1), (1, 1)]

# Set of tile types that interact with the game's physics system
PHYSICS_TILES = {'grass', 'stone'}

# Set of tile types that can have autotiling applied
AUTOTILE_TYPES = {'grass', 'stone'}

class Tilemap:
    def __init__(self, game, tile_size=16):
        self.game = game  # Reference to the game instance
        self.tile_size = tile_size  # Size of each tile
        self.tilemap = {}  # Dictionary to store tiles that are aligned to the grid
        self.offgrid_tiles = []  # List to store tiles that are not aligned to the grid

    def extract(self, id_pairs, keep=False):
        matches = []  # List to store tiles that match the specified type/variant pairs
        
        # Check offgrid tiles for matches
        for tile in self.offgrid_tiles.copy():
            if (tile['type'], tile['variant']) in id_pairs:
                matches.append(tile.copy())  # Add matching tile to list
                if not keep:
                    self.offgrid_tiles.remove(tile)  # Remove the tile if not keeping it
        
        # Check grid-based tiles for matches
        for loc in self.tilemap:
            tile = self.tilemap[loc]
            if (tile['type'], tile['variant']) in id_pairs:
                matches.append(tile.copy())  # Add matching tile to list
                matches[-1]['pos'] = matches[-1]['pos'].copy()  # Copy position
                matches[-1]['pos'][0] *= self.tile_size  # Convert position to pixel coordinates
                matches[-1]['pos'][1] *= self.tile_size
                if not keep:
                    del self.tilemap[loc]  # Remove the tile if not keeping it
        
        return matches  # Return the list of matching tiles

    def tiles_around(self, pos):
        tiles = []  # List to store neighboring tiles
        tile_loc = (int(pos[0] // self.tile_size)), (int(pos[1] // self.tile_size))  # Get the tile location based on the given position
        
        # Check for tiles in all neighboring positions
        for offset in NEIGHBOR_OFFSETS:
            check_loc = str(tile_loc[0] + offset[0]) + ';' + str(tile_loc[1] + offset[1])
            if check_loc in self.tilemap:
                tiles.append(self.tilemap[check_loc])  # Add neighboring tile to list
        return tiles  # Return the list of neighboring tiles
    
    def save(self, path):
        # Save the tilemap and related data to a JSON file
        with open(path, 'w') as f:
            json.dump({'tilemap': self.tilemap, 'tile_size': self.tile_size, 'offgrid': self.offgrid_tiles}, f)
        
    def load(self, path):
        # Load the tilemap and related data from a JSON file
        with open(path, 'r') as f:
            map_data = json.load(f)
        
        self.tilemap = map_data['tilemap']  # Load tilemap data
        self.tile_size = map_data['tile_size']  # Load tile size
        self.offgrid_tiles = map_data['offgrid']  # Load offgrid tiles
    
    def solid_check(self, pos):
        # Check if a given position corresponds to a solid (physics-enabled) tile
        tile_loc = str(int(pos[0] // self.tile_size)) + ';' + str(int(pos[1] // self.tile_size))
        if tile_loc in self.tilemap:
            if self.tilemap[tile_loc]['type'] in PHYSICS_TILES:
                return self.tilemap[tile_loc]  # Return the tile if it is solid

    def physics_rects_around(self, pos):
        rects = []  # List to store rectangles representing physics boundaries
        for tile in self.tiles_around(pos):
            if tile['type'] in PHYSICS_TILES:
                # Create a rectangle for each solid tile and add it to the list
                rects.append(pygame.Rect(tile['pos'][0] * self.tile_size, tile['pos'][1] * self.tile_size, self.tile_size, self.tile_size))
        return rects  # Return the list of rectangles
    
    def autotile(self):
        # Update tiles with appropriate autotile variants based on their neighbors
        for loc in self.tilemap:
            tile = self.tilemap[loc]
            neighbors = set()
            # Check for neighbors in each of the four directions
            for shift in [(1, 0), (-1, 0), (0, -1), (0, 1)]:
                check_loc = str(tile['pos'][0] + shift[0]) + ';' + str(tile['pos'][1] + shift[1])
                if check_loc in self.tilemap:
                    if self.tilemap[check_loc]['type'] == tile['type']:
                        neighbors.add(shift)  # Add neighbor to the set if it matches type
            neighbors = tuple(sorted(neighbors))  # Sort and convert neighbors set to tuple
            # Set the tile's variant based on its neighbors
            if (tile['type'] in AUTOTILE_TYPES) and (neighbors in AUTOTILE_MAP):
                tile['variant'] = AUTOTILE_MAP[neighbors]

    def render(self, surf, offset=(0, 0)):
    # Render offgrid tiles
        for tile in self.offgrid_tiles:
        # Draw each offgrid tile on the surface at its position, offset by the camera view
            surf.blit(self.game.assets[tile['type']][tile['variant']], (tile['pos'][0] - offset[0], tile['pos'][1] - offset[1]))

    # Render grid-based tiles within the visible area of the screen
    # Calculate the range of tiles to render based on the screen dimensions and the current offset
        for x in range(offset[0] // self.tile_size, (offset[0] + surf.get_width()) // self.tile_size + 1):
            for y in range(offset[1] // self.tile_size, (offset[1] + surf.get_height()) // self.tile_size + 1):
                loc = str(x) + ';' + str(y)  # Generate the location key for the tilemap dictionary
                if loc in self.tilemap:  # Check if the tile exists in the tilemap
                    tile = self.tilemap[loc]  # Get the tile data
                # Draw the tile on the surface at its position, offset by the camera view
                    surf.blit(self.game.assets[tile['type']][tile['variant']], (tile['pos'][0] * self.tile_size - offset[0], tile['pos'][1] * self.tile_size - offset[1]))

#AUTOTILE_MAP: Maps specific configurations of neighboring tiles to autotile variants. This allows tiles to change their appearance based on their surroundings, creating seamless transitions.

#NEIGHBOR_OFFSETS: A list of relative positions used to identify neighboring tiles.

#PHYSICS_TILES and AUTOTILE_TYPES: Define the types of tiles that participate in the game's physics system and those that can change appearance based on neighbors.

#Tilemap Class:

    #__init__: Initializes the tilemap, setting up a grid (tilemap) and a list for off-grid tiles (offgrid_tiles).

    #extract: Extracts tiles from the tilemap or off-grid tiles that match specific type/variant pairs. Optionally, the tiles can be removed from the tilemap.

    #tiles_around: Finds all tiles around a given position using predefined neighbor offsets.

    #save and load: Save and load the tilemap data to/from a JSON file.

    #solid_check: Checks if a position corresponds to a solid (physics-enabled) tile.

    #physics_rects_around: Returns rectangles representing the physics boundaries of tiles around a given position.

    #autotile: Automatically updates tiles in the map to their correct variants based on neighboring tiles, using the AUTOTILE_MAP.

    #render: Renders the tiles onto the screen, accounting for off-grid tiles and the camera's offset.

#This system allows the game to manage and render a grid-based tilemap while supporting advanced features like autotiling and physics integration.



